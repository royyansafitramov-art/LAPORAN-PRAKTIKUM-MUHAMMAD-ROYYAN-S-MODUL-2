data = []

while len(data) < 2:
    baris = input()
    if baris.strip():
        data.extend(baris.split())

r = float(data[0])
t = float(data[1])

PHI = 22 / 7

volume = PHI * (r ** 2) * t
luas = 2 * PHI * r * (r + t)
keliling = 2 * PHI * r

print(f"Volume = {volume:.2f}")
print(f"Luas = {luas:.2f}")
print(f"Keliling = {keliling:.2f}")