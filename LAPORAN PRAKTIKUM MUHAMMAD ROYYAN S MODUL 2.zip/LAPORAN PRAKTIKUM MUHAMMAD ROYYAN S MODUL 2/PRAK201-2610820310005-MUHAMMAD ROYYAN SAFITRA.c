#include <stdio.h>
#include <string.h>

int main() {
    char nama[100];
    char nim[30];
    char kelas[30];
    char tempat_lahir[100];
    char alamat[200];
    char hobby[100];
    char no_hp[30];

    printf("=== INPUT BIODATA ===\n");

    printf("Nama                 : ");
    fgets(nama, sizeof(nama), stdin);

    printf("NIM                  : ");
    fgets(nim, sizeof(nim), stdin);

    printf("Kelas Paralel        : ");
    fgets(kelas, sizeof(kelas), stdin);

    printf("Tempat/Tanggal Lahir : ");
    fgets(tempat_lahir, sizeof(tempat_lahir), stdin);

    printf("Alamat               : ");
    fgets(alamat, sizeof(alamat), stdin);

    printf("Hobby                : ");
    fgets(hobby, sizeof(hobby), stdin);

    printf("No. HP               : ");
    fgets(no_hp, sizeof(no_hp), stdin);

    nama[strcspn(nama, "\n")] = '\0';
    nim[strcspn(nim, "\n")] = '\0';
    kelas[strcspn(kelas, "\n")] = '\0';
    tempat_lahir[strcspn(tempat_lahir, "\n")] = '\0';
    alamat[strcspn(alamat, "\n")] = '\0';
    hobby[strcspn(hobby, "\n")] = '\0';
    no_hp[strcspn(no_hp, "\n")] = '\0';

    printf("\n=== OUTPUT BIODATA ===\n");
    printf("Nama                 : %s\n", nama);
    printf("NIM                  : %s\n", nim);
    printf("Kelas Paralel        : %s\n", kelas);
    printf("Tempat/Tanggal Lahir : %s\n", tempat_lahir);
    printf("Alamat               : %s\n", alamat);
    printf("Hobby                : %s\n", hobby);
    printf("No. HP               : %s\n", no_hp);

    return 0;
}