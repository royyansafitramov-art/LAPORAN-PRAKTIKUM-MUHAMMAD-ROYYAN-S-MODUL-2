import math

data = []

while len(data) < 2:
    baris = input()
    if baris.strip():
        data.extend(baris.split())

a = int(data[0])
b = int(data[1])

c = int(math.sqrt(b**2 - a**2))
keliling = a + b + c
luas = int(0.5 * c * a)

print(f"Alas = {c} cm")
print(f"Tinggi = {a} cm")
print(f"Keliling = {keliling} cm")
print(f"Luas = {luas} cm^2")