#include <stdio.h>
#include <math.h>

int main() {
    int a, b;

    if (scanf("%d %d", &a, &b) == 2) {
        int c = sqrt(b * b - a * a);
        int keliling = a + b + c;
        int luas = 0.5 * c * a;

        printf("Alas = %d cm\n", c);
        printf("Tinggi = %d cm\n", a);
        printf("Keliling = %d cm\n", keliling);
        printf("Luas = %d cm^2\n", luas);
    }

    return 0;
}